const guildId = '1065753106966650930'; // Server ID (Make Sure The Account are in it and verified or something) or put it in a secret named guild
const channelId = '1192438865227694101'; // Channel ID (Make sure The account have access to join it) or put it in a secret named channel
const autoClaim = false; // Edit this to true to make the accounts auto claim nitro codes

// New configuration options
const textChannelId = '1245896003916140584'; // Replace with your text channel ID
const messages = [
  '!صباحححو',
  'مسااوو?',
  'ضحك ضحك!',
  // Add more messages here
];

module.exports = { 
  guildId,
  channelId,
  autoClaim,
  textChannelId,
  messages
};
